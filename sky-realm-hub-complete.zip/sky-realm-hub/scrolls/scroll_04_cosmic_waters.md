**"The water remembers what the fire forgot."**
— *Codex Fragment 888: The Alchemy of Light*