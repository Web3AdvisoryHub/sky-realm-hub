**"Time does not move — we do. Each step we take carves the trail we later call memory."**
— *Clio, Keeper of the Fractured Clock*