# Site V2 Goals – Web3 Learning Hub x Codex Ecosystem

Last updated: 2025-03-27  
Owner: Calvi / Manus  
Repo: `sky-realm-hub`

## Vision
Transform the Web3 learning experience into an immersive, dual-chain platform...

## Phase 1 (1–2 weeks)
- [x] Split-entry homepage
- [x] Sky Realm visual update
- [x] Wallet connection system
- [x] Clickable chapter tiles
- [x] Mobile-first layout

## Phase 2–3...
