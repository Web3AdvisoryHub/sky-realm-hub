**"To see all, you must weep once."**
— *Inscription beneath the Six-Winged Eye of Ci*