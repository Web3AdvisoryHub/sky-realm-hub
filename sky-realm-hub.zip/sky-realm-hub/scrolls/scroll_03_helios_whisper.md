**"My father built stars from breath. Each galaxy was just a thought he let go of."**
— *Helios, as recorded in the Rift Codex*